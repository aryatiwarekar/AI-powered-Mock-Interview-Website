from django.views import View
import pdfplumber
import re
import openai
import nltk
from django.shortcuts import render, redirect, get_object_or_404
from .models import Question, UserAnswer, JobApplication, JobList, JobCategory, Customer
from nltk.tokenize import word_tokenize
from .import models
from .forms import RegistrationForm, UploadFileForm, AnswerForm, JobApplicationForm, JobListForm
from django.contrib import messages
from django.forms import modelformset_factory
from django.http import HttpResponse
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.auth.models import User 



def home(request):
    return render(request, 'app/index.html')

def upload_resume(request):
    return render(request, 'app/upload_resume.html')


def login(request):
    render(request, 'app/login.html')
    return redirect("app/index.html")


#########################################################
# def user_registration(request):
#     if request.method == 'POST':
#         form = RegistrationForm(request.POST)
#         if form.is_valid():
#             user = form.save()
#             login(request, user)
#             Customer.objects.create(user=user)
#             return redirect('home')
#     else:
#         form = RegistrationForm()
#         return render(request, 'app/signup.html', {'form': form})


###########################################################


class RegistrationView(View):
    def get(self, request):
        form = RegistrationForm()
        return render(request, 'app/signup.html', {'form': form})

    def post(self, request):
        form = RegistrationForm(request.POST)
        if form.is_valid():
            messages.success(
                request, 'Successfuly Registered. Please login to continue.')
            form.save()
        return render(request, 'app/signup.html', {'form': form})



openai.api_key = "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"

nltk.download('punkt')

from nltk.tokenize import word_tokenize

def extract_skills(text, skill_keywords):
    extracted_skills = []
    for skill in skill_keywords:
        if re.search(re.escape(skill), text, re.IGNORECASE):
            extracted_skills.append(skill)
    return extracted_skills

def generate_question_and_answer(skill, used_questions):
    prompt = f"Generate interview question and answer about {skill}"

    while True:
        response = openai.Completion.create(
            engine="gpt-3.5-turbo-instruct",
            prompt=prompt,
            max_tokens=150,
            temperature=0.7,
            n=1,
            stop=None,
        )

        question_answer = response['choices'][0]['text'].strip().split('\n')
        question = question_answer[0]
        if question not in used_questions:
            used_questions.add(question)
            answer = question_answer[1].strip() if len(question_answer) > 1 else "No correct answer available for this question."
            return question, answer

def calculate_accuracy(user_answers):
    total_accuracy = 0
    total_questions = len(user_answers)

    for question, correct_answer, user_answer in user_answers:
        if correct_answer != "No correct answer available for this question.":
            correct_tokens = set(word_tokenize(correct_answer.lower()))
            user_tokens = set(word_tokenize(user_answer.lower()))
            jaccard_similarity = 1 - nltk.jaccard_distance(correct_tokens, user_tokens)
            accuracy = min(1, max(0, jaccard_similarity)) * 100
        else:
            accuracy = 0

        total_accuracy += accuracy

    return total_accuracy / total_questions

from django.http import Http404

def upload(request):
    if request.method == 'POST':
        form = UploadFileForm(request.POST, request.FILES)
        if form.is_valid():
            # Extract text from PDF
            with pdfplumber.open(request.FILES['file']) as pdf:
                text = ""
                for page in pdf.pages:
                    text += page.extract_text()

            # Extract skills from text
            skill_keywords = ["python", "mechanical", "automobile"]  # Add more skills/keywords as needed
            skills = extract_skills(text, skill_keywords)

            # Generate questions and answers for each skill and save them to the database
            used_questions = set()
            for skill in skills:
                for _ in range(3):  # Generate 3 questions per skill
                    question_text, correct_answer = generate_question_and_answer(skill, used_questions)
                    Question.objects.create(question_text=question_text, correct_answer=correct_answer)

            # Check if questions were generated
            if Question.objects.exists():
                return redirect('question', question_id=1)
            else:
                # Redirect to a page indicating no questions were generated
                return render(request, 'app/no_questions_generated.html')  # Change this line to the correct template name
    else:
        form = UploadFileForm()
    return render(request, 'app/upload_resume.html', {'form': form})

def question(request, question_id):
    try:
        question = Question.objects.get(id=question_id)
    except Question.DoesNotExist:
        raise Http404("Question does not exist")

    if request.method == 'POST':
        form = AnswerForm(request.POST)
        if form.is_valid():
            # Save user's answer to the database
            UserAnswer.objects.create(question=question, user_answer=form.cleaned_data['answer'])

            # Redirect to the next question or to the answers page if there are no more questions
            next_question_id = question_id + 1
            if Question.objects.filter(id=next_question_id).exists():
                return redirect('question', question_id=next_question_id)
            else:
                return redirect('accuracy')
    else:
        form = AnswerForm()
    return render(request, 'app/questions.html', {'form': form, 'question': question})

def accuracy(request):
    # Retrieve all questions
    questions = Question.objects.all()

    # Retrieve user answers
    user_answers = UserAnswer.objects.all()

    # Calculate accuracy
    accuracy = calculate_accuracy([(ua.question.question_text, ua.question.correct_answer, ua.user_answer) for ua in user_answers])

    # Delete all user answers
    UserAnswer.objects.all().delete()

    # Delete all questions
    Question.objects.all().delete()

    return render(request, 'app/accuracy.html', {'accuracy': accuracy, 'questions': questions})


def answers(request):
    questions = Question.objects.all()
    return render(request, 'app/answers.html', {'questions': questions})




# Job Portal

def job_list(request):
    job_listings = JobList.objects.all()
    categories = JobCategory.objects.all()

    category_filter = request.GET.get('category')
    location_filter = request.GET.get('location')

    if category_filter:
        job_listings = job_listings.filter(category__name=category_filter)
    if location_filter:
        job_listings = job_listings.filter(location=location_filter)

    context = {
        'job_listings': job_listings,
        'categories': categories,
    }

    return render(request, 'jobs/home.html', context)


#
def apply_job(request, job_id):
    job = JobList.objects.get(id=job_id)
    if request.method == 'POST':
        form = JobApplicationForm(request.POST, request.FILES)
        if form.is_valid():
            application = form.save(commit=False)
            application.job = job
            application.user = request.user
            application.save()
            messages.success(request, 'Job application submitted successfully.')
            return redirect('profile')
    else:
        form = JobApplicationForm()
    return render(request, 'jobs/apply.html', {'form': form, 'job': job})


#
def profile(request):
    user = request.user
    applied_jobs = JobApplication.objects.filter(user=user)
    context = {
        'user': user,
        'applied_jobs': applied_jobs,
    }
    return render(request, 'jobs/profile.html', context)


def job_details(request, job_id):
    job = JobList.objects.get(pk=job_id)
    return render(request, 'jobs/details.html', {'job': job})





#
def job_listings(request):
    user = request.user
    job_listings = JobList.objects.filter(user=user)
    return render(request, 'jobs/job_listings.html', {'job_listings': job_listings})

# 
def create_job(request):
    if request.method == 'POST':
        form = JobListForm(request.POST)
        if form.is_valid():
            job_listing = form.save(commit=False)
            job_listing.user = request.user
            job_listing.save()
            return redirect('job_listings')
    else:
        form = JobListForm()
    return render(request, 'jobs/create_job.html', {'form': form})

# 
def edit_job(request, job_id):
    job_listing = get_object_or_404(JobList, pk=job_id)
    
    # Check if the logged-in user is the owner of the job listing
    if job_listing.user != request.user:
        return redirect('job_listings')

    if request.method == 'POST':
        form = JobListForm(request.POST, instance=job_listing)
        if form.is_valid():
            form.save()
            return redirect('job_listings')
    else:
        form = JobListForm(instance=job_listing)

    return render(request, 'jobs/edit_job.html', {'form': form, 'job_listing': job_listing})

# 
def delete_job(request, job_id):
    job_listing = get_object_or_404(JobList, pk=job_id)
    
    # Check if the logged-in user is the owner of the job listing
    if job_listing.user != request.user:
        return redirect('job_listings')

    if request.method == 'POST':
        job_listing.delete()
        return redirect('job_listings')
    return render(request, 'jobs/delete_job.html', {'job_listing': job_listing})

# 
def job_applications(request, job_id):
    job_listing = get_object_or_404(JobList, id=job_id)
    applications = JobApplication.objects.filter(job=job_listing)
    return render(request, 'jobs/job_applications.html', {'job_listing': job_listing, 'applications': applications})


