from django.contrib import admin
from .models import Customer
from django.utils.html import format_html
from django.urls import reverse
from .models import Question, UserAnswer



# Register your models here.



admin.site.site_header = 'Mock Interview'


@admin.register(Customer)
class CustomerAdmin(admin.ModelAdmin):
    list_display = ['id', 'user', 'name', 'phone']

from .models import Question

class QuestionAdmin(admin.ModelAdmin):
    list_display = ('question_text', 'correct_answer')

admin.site.register(Question, QuestionAdmin)

# admin.site.register(UserAnswer)
class UserAnswerAdmin(admin.ModelAdmin):
    list_display = ('question', 'user_answer')

admin.site.register(UserAnswer, UserAnswerAdmin)


# @admin.register(Resume)
# class ResumeAdmin(admin.ModelAdmin):
#     list_display = ['pdf_file']

# @admin.register(Question)
# class QuestionAdmin(admin.ModelAdmin):
#     list_display = ['question_text', 'correct_answer']

# @admin.register(Answer)
# class AnswerAdmin(admin.ModelAdmin):
#     list_display = ['question', 'user_answer', 'accuracy', 'resume']
