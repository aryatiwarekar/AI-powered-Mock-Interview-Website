from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from . import views
from django.contrib.auth import authenticate, views as auth_views
from .forms import LoginForm, RegistrationForm
from . import views

urlpatterns = [
    path('', views.home, name="home"),
    path('accounts/login', auth_views.LoginView.as_view(template_name='app/login.html',
                                                                      authentication_form=LoginForm),  name='login'),
    path('accounts/logout/',
         auth_views.LogoutView.as_view(next_page='home'), name='logout'),
    path('registration/', views.RegistrationView.as_view(), name='registration'),
    path('upload_resume/', views.upload, name='upload_resume'),
    path('question/<int:question_id>/', views.question, name='question'),
    path('answers/', views.answers, name='answers'),
    path('accuracy/', views.accuracy, name='accuracy'),
    # Job Portal
    path('job_list/', views.job_list, name='job_list'),
    path('job/<int:job_id>/apply/', views.apply_job, name='apply_job'),
    path('profile/', views.profile, name='profile'),
    path('job_listings/', views.job_listings, name='job_listings'),
    path('create_job_listing/', views.create_job, name='create_job_listing'),
    path('edit_job_listing/<int:job_id>/', views.edit_job, name='edit_job_listing'),
    path('delete_job_listing/<int:job_id>/', views.delete_job, name='delete_job_listing'),
    path('job_applications/<int:job_id>/', views.job_applications, name='job_applications'),
    path('job/<int:job_id>/', views.job_details, name='job_details'),
]
