from django import contrib, forms
from django.contrib.auth import authenticate, password_validation
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm, UsernameField, PasswordChangeForm, PasswordResetForm, SetPasswordForm
from django.contrib.auth.models import User
from django.forms import fields, widgets
from django.shortcuts import render
from django.utils.translation import gettext, gettext_lazy as gt
from .models import Customer, UserAnswer, JobApplication, JobList



#To register a new user.
class RegistrationForm(UserCreationForm):
    username = forms.CharField(
        label='Username', widget=forms.TextInput(attrs={'class': 'form-control'}))
    password1 = forms.CharField(
        label='Password', widget=forms.PasswordInput(attrs={'class': 'form-control'}))
    password2 = forms.CharField(label='Confirm Password', widget=forms.PasswordInput(
        attrs={'class': 'form-control'}))
    email = forms.CharField(required=True, widget=forms.EmailInput(
        attrs={'class': 'form-control'}))
    phone = forms.IntegerField(required=True, widget=forms.TextInput(
        attrs={'class': 'form-control'}))

    class Meta:
        model = User
        fields = ['username', 'email', 'phone', 'password1', 'password2']
        labels = {'email': 'Email'}
        widgets = {'username': forms.TextInput(attrs={'class': 'form-control'})}


#Login for existing user
class LoginForm(AuthenticationForm):
    username = UsernameField(widget=forms.TextInput(
        attrs={'autofocus': True, 'class': 'form-control'}))
    password = forms.CharField(label=('Password'), strip=False, widget=forms.PasswordInput(
        attrs={'autocomplete': 'current-password', 'class': 'form-control'}))
    


class UploadFileForm(forms.Form):
    file = forms.FileField()

class AnswerForm(forms.Form):
    answer = forms.CharField(widget=forms.Textarea(
        attrs={'autofocus': True, 'class': 'form-control'}
    ))


# Job Portal
    

class JobApplicationForm(forms.ModelForm):
    class Meta:
        model = JobApplication
        fields = ['name', 'phone', 'email', 'location', 'resume', 'latest_qualification']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control'}),
            'phone': forms.TextInput(attrs={'class': 'form-control'}),
            'email': forms.TextInput(attrs={'class': 'form-control'}),
            'location': forms.TextInput(attrs={'class': 'form-control'}),
            'resume': forms.FileInput(attrs={'class': 'form-control-file'}),
            'latest_qualification': forms.TextInput(attrs={'class': 'form-control'}),
        }


class JobListForm(forms.ModelForm):
    class Meta:
        model = JobList
        fields = ['title', 'description', 'location', 'category']
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control'}),
            'description': forms.Textarea(attrs={'class': 'form-control'}),
            'location': forms.TextInput(attrs={'class': 'form-control'}),
            'category': forms.Select(attrs={'class': 'form-control'}),
        }


# class UserProfileForm(forms.ModelForm):
#     class Meta:
#         model = Customer
#         fields = ['bio', 'linkedin_profile', 'website']
#         widgets = {
#             'bio': forms.Textarea(attrs={'class': 'form-control'}),
#             'linkedin_profile': forms.TextInput(attrs={'class': 'form-control'}),
#             'website': forms.TextInput(attrs={'class': 'form-control'}),
#         }